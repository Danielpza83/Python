from setuptools import setup

setup(
    name="My Package",
    version="1.0",
    description="Package of variable and matematics functions",
    author="Daniel Maestre",
    author_email="dmaestre1490@gmail.com",
    packages=["package"]
)