import sys

nombre = sys.argv

for n in nombre[1:]:
    print(f"Hola {n}! Bienvenido!")
